<?php
/**
 * Include Files
 * 
 * @package    wp-ulike
 * @author     Alimir 2018
 * @link       https://wpulike.com
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die('No Naughty Business Please !');
}

include_once( 'general-functions.php' );
include_once( 'general-hooks.php' );