<?php
// Silence is golden.
