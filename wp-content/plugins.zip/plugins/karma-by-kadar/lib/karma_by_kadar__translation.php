<?php

if ( ! defined( 'ABSPATH' ) ) { exit; }

load_plugin_textdomain( 'karma-by-kadar', false, KARMA_BY_KADAR__PLUGIN_DIR_NAME . '/languages' );